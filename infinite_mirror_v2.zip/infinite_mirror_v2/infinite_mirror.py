"""
THE INFINITE MIRROR  -  v2
A journey through an endless reflection.

Chapters
  I    THE FIRST REFLECTION       light beam in the dark
  II   THE INFINITE CORRIDOR      blue neon tunnel
  III  THE COLOUR TRANSFORMATION  blue -> purple
  IV   THE IMPOSSIBLE SPACE       tunnel starts to roll and twist
  V    THE INFINITE CORE          kaleidoscope, white flash
  --   HOW FAR DOES INFINITY GO?

Usage
  python infinite_mirror.py                  # renders 1080x1920 MP4 with sound
  python infinite_mirror.py --out reel.mp4
  python infinite_mirror.py --fps 60         # smoother (slower to render)
  python infinite_mirror.py --stills         # quick check: saves a few PNG frames

Install
  pip install numpy opencv-python pillow imageio-ffmpeg
"""

import argparse
import math
import os
import shutil
import subprocess
import sys
import wave

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont

# ----------------------------------------------------------------------------
# Global settings
# ----------------------------------------------------------------------------
W, H = 1080, 1920
DUR = 21.2                      # seconds
HERE = os.path.dirname(os.path.abspath(__file__))

F_PX = 520.0                    # focal length (px)
A, B = 1.0, 1.5                 # tunnel half width / half height
NR = 28                         # rings alive at once
D = 1.15                        # ring spacing
ZMIN = 0.75
ZFAR = ZMIN + NR * D

BEATS = (3.0, 6.6, 10.6)        # bass-hit times (sync with audio)

CHAPTERS = [                    # (start, end, text)
    (0.00, 1.90, "I  \u2014  THE FIRST REFLECTION"),
    (1.90, 4.90, "II  \u2014  THE INFINITE CORRIDOR"),
    (4.90, 8.60, "III  \u2014  THE COLOUR TRANSFORMATION"),
    (8.80, 12.0, "IV  \u2014  THE IMPOSSIBLE SPACE"),
    (12.0, 15.0, "V  \u2014  THE INFINITE CORE"),
]

# palettes in RGB
BLUE = dict(core=(165, 215, 255), glow=(45, 130, 255), wall=(28, 90, 235))
PURP = dict(core=(228, 165, 255), glow=(170, 55, 255), wall=(130, 40, 225))


# ----------------------------------------------------------------------------
# Small helpers
# ----------------------------------------------------------------------------
def clamp(x, a=0.0, b=1.0):
    return max(a, min(b, x))


def sstep(a, b, x):
    x = clamp((x - a) / (b - a))
    return x * x * (3 - 2 * x)


def mix3(a, b, p):
    return tuple(a[i] * (1 - p) + b[i] * p for i in range(3))


def bgr(c, k=1.0):
    m = max(c) * k
    if m > 255:                      # keep the hue instead of clipping towards white
        k *= 255.0 / m
    return (int(clamp(c[2] * k, 0, 255)), int(clamp(c[1] * k, 0, 255)), int(clamp(c[0] * k, 0, 255)))


def palette(t):
    p = sstep(5.0, 8.4, t)
    return {k: mix3(BLUE[k], PURP[k], p) for k in BLUE}


def beat_pulse(t):
    v = 0.0
    for b in BEATS:
        if t >= b:
            v += math.exp(-(t - b) * 4.5)
    return v


# ---- timeline curves --------------------------------------------------------
_KEYS = [(0, 0.0), (0.8, 0.5), (1.7, 1.5), (2.9, 2.0), (3.2, 3.6), (6.5, 3.8),
         (6.7, 5.0), (10.5, 5.4), (10.7, 6.8), (14.5, 7.8), (16.2, 9.5), (21.2, 9.5)]
_tt = np.linspace(0, DUR + 1, int((DUR + 1) * 1000) + 1)
_vv = np.interp(_tt, [k[0] for k in _KEYS], [k[1] for k in _KEYS])
_PP = np.cumsum(_vv) * (_tt[1] - _tt[0])


def travel(t):
    """Distance travelled down the corridor."""
    return float(np.interp(t, _tt, _PP))


def roll_angle(t):
    return 0.78 * sstep(8.8, 9.6, t) * math.sin(2 * math.pi * (t - 9.2) / 4.0) * (1 - sstep(14.0, 14.7, t))


def twist_amt(t):
    return 0.20 * sstep(10.0, 12.0, t) * (0.65 + 0.35 * math.sin(t * 0.9)) * (1 - sstep(14.0, 14.7, t))


def camera(t):
    k = sstep(2.0, 3.5, t)
    return (W / 2 + W * 0.022 * math.sin(t * 0.8) * k,
            H / 2 + H * 0.010 * math.sin(t * 0.6 + 1.0) * k)


# ----------------------------------------------------------------------------
# Text overlays (Pillow, pre-rendered once)
# ----------------------------------------------------------------------------
def load_font(name, size):
    for p in (os.path.join(HERE, "fonts", name),
              "C:/Windows/Fonts/arialbd.ttf", "C:/Windows/Fonts/arial.ttf",
              "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
              "/Library/Fonts/Arial Bold.ttf"):
        if os.path.exists(p):
            try:
                return ImageFont.truetype(p, size)
            except Exception:
                pass
    return ImageFont.load_default()


def tracked_width(draw, text, font, track):
    w = 0
    for ch in text:
        w += draw.textlength(ch, font=font) + track
    return w - track


def draw_tracked(draw, xy, text, font, track, fill):
    x, y = xy
    for ch in text:
        draw.text((x, y), ch, font=font, fill=fill)
        x += draw.textlength(ch, font=font) + track


def make_label(text):
    img = Image.new("L", (W, H), 0)
    d = ImageDraw.Draw(img)
    font = load_font("Poppins-Medium.ttf", 27)
    track = 9
    tw = tracked_width(d, text, font, track)
    draw_tracked(d, ((W - tw) / 2, H * 0.905), text, font, track, 150)
    return np.asarray(img, dtype=np.uint8)


def make_outro():
    img = Image.new("L", (W, H), 0)
    d = ImageDraw.Draw(img)
    lines = ["HOW FAR DOES", "INFINITY GO?"]
    target = W * 0.70
    size = 80
    font = load_font("Poppins-Bold.ttf", size)
    track = size * 0.14
    for _ in range(14):                       # fit width of first line
        font = load_font("Poppins-Bold.ttf", size)
        track = size * 0.14
        w = tracked_width(d, lines[0], font, track)
        size = int(size * target / w)
    font = load_font("Poppins-Bold.ttf", size)
    track = size * 0.14
    lh = size * 1.32
    top = H * 0.515 - lh
    for i, ln in enumerate(lines):
        tw = tracked_width(d, ln, font, track)
        draw_tracked(d, ((W - tw) / 2, top + i * lh), ln, font, track, 255)
    txt = np.asarray(img, dtype=np.uint8)
    # thin lines above / below
    rule = np.zeros((H, W, 3), np.uint8)
    lw = int(W * 0.30)
    x0 = (W - lw) // 2
    y_top = int(top - size * 0.55)
    y_bot = int(top + 2 * lh + size * 0.05)
    cv2.line(rule, (x0, y_top), (x0 + lw, y_top), (170, 170, 170), 2, cv2.LINE_AA)
    cv2.line(rule, (x0, y_bot), (x0 + lw, y_bot), (215, 90, 70), 2, cv2.LINE_AA)   # BGR -> blue
    return txt, rule


# ----------------------------------------------------------------------------
# Renderer
# ----------------------------------------------------------------------------
class Mirror:
    def __init__(self):
        self.Wh, self.Hh = W // 2, H // 2
        Y, X = np.mgrid[0:self.Hh, 0:self.Wh].astype(np.float32)
        self.Xh, self.Yh = X, Y
        rng = np.random.default_rng(7)

        # streak noise, per angle (sparse bright rays)
        def ray_noise(seed, n=1440):
            r = np.random.default_rng(seed).random(n).astype(np.float32)
            pad = np.concatenate([r[-24:], r, r[:24]]).reshape(1, -1)      # wrap-around blur
            r = cv2.GaussianBlur(pad, (0, 0), 3.2).ravel()[24:-24]
            r = (r - r.min()) / (r.max() - r.min())
            return r ** 1.7
        self.NS = 1440
        self.S0, self.S1 = ray_noise(1), ray_noise(2)
        w = np.random.default_rng(5).random(1440).astype(np.float32)
        padw = np.concatenate([w[-200:], w, w[:200]]).reshape(1, -1)
        w = cv2.GaussianBlur(padw, (0, 0), 38).ravel()[200:-200]
        self.WEDGE = ((w - w.min()) / (w.max() - w.min())) ** 1.4

        # vignette
        yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
        r2 = ((xx - W / 2) / (W / 2)) ** 2 + ((yy - H / 2) / (H / 2)) ** 2
        v = np.clip(1.0 - 0.24 * r2 ** 0.9, 0, 1)
        self.vig = cv2.merge([(v * 255).astype(np.uint8)] * 3)

        # quarter-res radial map for core glow
        q = 4
        yq, xq = np.mgrid[0:H // q, 0:W // q].astype(np.float32)
        self.rq2 = (((xq - W / q / 2) / (W / q / 2)) ** 2 + ((yq - H / q / 2) / (H / q / 2) * 0.62) ** 2)

        # sparks
        self.spark = np.random.default_rng(11)
        self.sp_x = self.spark.uniform(-0.92, 0.92, 220) * A
        self.sp_y = self.spark.uniform(-0.92, 0.92, 220) * B
        far = (self.sp_x / A) ** 2 + (self.sp_y / B) ** 2 < 0.22          # keep the centre clear
        self.sp_x[far] *= 2.2
        self.sp_y[far] *= 2.2
        self.sp_x = np.clip(self.sp_x, -0.95, 0.95)
        self.sp_y = np.clip(self.sp_y, -0.95 * B, 0.95 * B)
        self.sp_z0 = self.spark.uniform(1.0, 34.0, 220)
        self.sp_v = self.spark.uniform(0.8, 1.6, 220)
        self.sp_rank = self.spark.random(220)

        # text
        self.labels = [(s, e, make_label(tx)) for s, e, tx in CHAPTERS]
        self.outro_txt, self.outro_rule = make_outro()

    # ------------------------------------------------------------------
    def proj(self, x, y, z, psi, cx, cy):
        c, s = math.cos(psi), math.sin(psi)
        xr = x * c - y * s
        yr = x * s + y * c
        return cx + F_PX * xr / z, cy + F_PX * yr / z

    def pts(self, corners, z, psi_fn, cx, cy):
        return np.array([self.proj(x, y, z, psi_fn(z), cx, cy) for x, y in corners], np.int32)

    # ------------------------------------------------------------------
    def walls(self, t, cx, cy, roll, P, pal, gain):
        dx = self.Xh - cx / 2
        dy = self.Yh - cy / 2
        c, s = math.cos(roll), math.sin(roll)
        u = dx * c + dy * s
        v = -dx * s + dy * c
        au, av = np.abs(u) / A, np.abs(v) / B
        q = np.maximum(au, av) + 1e-3
        z = (F_PX / 2) / q
        ang = np.arctan2(v, u)
        idx = ((ang + math.pi) / (2 * math.pi) * self.NS).astype(np.int32) % self.NS
        m = 0.5 + 0.5 * math.sin(t * 1.9)
        st = self.S0[idx] * (1 - m) + self.S1[idx] * m
        phase = (z + P - ZMIN) / D
        band = (0.5 + 0.5 * np.cos(2 * math.pi * phase)) ** 6
        near = 1.0 / (0.55 + 0.5 * z)
        I = near * (0.10 + 0.62 * st) + 0.30 * near * band
        side2d = (au > av).astype(np.float32)
        wedge = self.WEDGE[(idx + int(t * 12)) % self.NS]
        I = I + near * (0.85 + 0.35 * sstep(6, 9, t)) * wedge * (0.55 + 0.45 * side2d) * (0.55 + 0.45 * math.sin(t * 0.7 + 1))
        I = 1.15 * np.tanh(I / 1.15) * gain
        side = side2d[..., None]
        wc = np.array(pal["wall"][::-1], np.float32) / 255.0                 # BGR
        fl = np.array(mix3(pal["wall"], (150, 165, 200), 0.55)[::-1], np.float32) / 255.0
        col = side * wc + (1 - side) * fl
        out = np.clip(I[..., None] * col * 255.0, 0, 255).astype(np.uint8)
        return cv2.resize(out, (W, H), interpolation=cv2.INTER_LINEAR)

    # ------------------------------------------------------------------
    def beam(self, t, pal):
        """Chapter I: the first reflection - a vertical beam and its ghosts."""
        a = (0.30 + 0.70 * sstep(0.0, 0.45, t)) * (1 - sstep(0.65, 1.15, t))
        if a <= 0.001:
            return None
        Wh, Hh = self.Wh, self.Hh
        x = np.arange(Wh, dtype=np.float32)
        w0 = Wh * (0.020 + 0.030 * sstep(0.0, 1.2, t))
        col = np.exp(-((x - Wh / 2) / w0) ** 2) * 1.0 + np.exp(-((x - Wh / 2) / (w0 * 4.0)) ** 2) * 0.35
        for i, (off, amp) in enumerate(((0.11, 0.55), (0.19, 0.38), (0.28, 0.22))):
            sp = off * (0.7 + 0.5 * sstep(0, 1.5, t)) * Wh
            wi = w0 * (0.35 + i * 0.12)
            for sgn in (-1, 1):
                col += amp * np.exp(-((x - Wh / 2 - sgn * sp) / wi) ** 2) * (0.6 + 0.4 * math.sin(t * 5 + i))
        y = np.linspace(-1, 1, Hh, dtype=np.float32)
        vprof = (1 - 0.55 * np.abs(y) ** 2.2)[:, None]
        img = vprof * col[None, :]
        c = np.array(mix3(pal["core"], pal["glow"], 0.4)[::-1], np.float32) / 255.0
        out = np.clip(img[..., None] * c * 255.0 * a * 1.45, 0, 255).astype(np.uint8)
        return cv2.resize(out, (W, H), interpolation=cv2.INTER_LINEAR)

    # ------------------------------------------------------------------
    def frame(self, t):
        pal = palette(t)
        cx, cy = camera(t)
        roll, tw = roll_angle(t), twist_amt(t)
        P = travel(t)
        pulse = beat_pulse(t)
        corridor = sstep(0.55, 1.5, t)
        psi = lambda z: roll + tw * (z - 1.0)
        psi2 = lambda z: -roll * 1.15 - tw * (z - 1.0) * 0.85 + 0.35

        core_bgr = bgr(pal["core"])
        glow_bgr = bgr(pal["glow"])

        # --- walls (soft, half-res) -----------------------------------
        base = self.walls(t, cx, cy, roll, P, pal, gain=corridor * (0.85 + 0.5 * pulse))

        # --- crisp line layers ----------------------------------------
        L1 = np.zeros((H, W, 3), np.uint8)
        L2 = np.zeros((H, W, 3), np.uint8)
        corners = [(-A, -B), (A, -B), (A, B), (-A, B)]

        def ring_set(Lg, Lc, offset, psi_fn, kscale):
            for k in range(NR):
                z = ZMIN + ((k * D + offset - P) % (NR * D))
                a = sstep(ZMIN, ZMIN + 0.55, z) * (1 - sstep(ZFAR - 9, ZFAR, z)) * corridor * kscale
                a *= 0.10 + 0.90 * (1 - sstep(1.8, 10, z))
                if a < 0.02:
                    continue
                br = (0.55 + 0.45 * min(1.0, 2.0 / z)) * (1 + 0.5 * pulse)
                pts = self.pts(corners, z, psi_fn, cx, cy)
                tg = max(2, int(round(1.5 + 28 / z ** 1.1)))
                tc = max(1, int(round(1 + 11.0 / z)))
                cv2.polylines(Lg, [pts], True, bgr(pal["glow"], a * br * 1.05), tg, cv2.LINE_AA)
                cv2.polylines(Lc, [pts], True, bgr(pal["core"], a * br * 0.82), tc, cv2.LINE_AA)

        ring_set(L1, L2, 0.0, psi, 1.0)
        kal = sstep(11.2, 12.4, t) * (1 - sstep(14.0, 14.6, t))
        if kal > 0.01:
            ring_set(L1, L2, D * 0.5, psi2, 0.8 * kal)

        # corner edges of the tunnel
        for sx, sy in corners:
            zs = ZMIN * 0.8 * (1.13 ** np.arange(0, 42))
            edge = np.array([self.proj(sx, sy, z, psi(z), cx, cy) for z in zs], np.int32)
            k_out = int(np.searchsorted(zs, 2.8)) + 1
            cv2.polylines(L1, [edge[:k_out]], False, bgr(pal["glow"], 0.95 * corridor), 7, cv2.LINE_AA)
            cv2.polylines(L2, [edge[:k_out]], False, bgr(pal["core"], 0.55 * corridor), 2, cv2.LINE_AA)
            cv2.polylines(L1, [edge[k_out - 1:]], False, bgr(pal["glow"], 0.22 * corridor), 3, cv2.LINE_AA)

        # floor + ceiling lane lights
        for sgn in (-1, 1):
            for j in range(NR):
                z0 = ZMIN * 0.55 + ((j * D + 0.25 - P) % (NR * D))
                z1 = z0 + 0.50
                if z1 < 0.85:
                    continue
                z0 = max(z0, 0.8)
                a = (1 - sstep(ZFAR - 10, ZFAR, z0)) * corridor
                if a < 0.02:
                    continue
                quad = np.array([self.proj(-0.07, sgn * B, z0, psi(z0), cx, cy),
                                 self.proj(0.07, sgn * B, z0, psi(z0), cx, cy),
                                 self.proj(0.07, sgn * B, z1, psi(z1), cx, cy),
                                 self.proj(-0.07, sgn * B, z1, psi(z1), cx, cy)], np.int32)
                a *= 0.30 + 0.70 * sstep(0.9, 2.2, z0)
                cv2.fillConvexPoly(L2, quad, bgr(mix3(pal["core"], pal["glow"], 0.35), a * (0.62 + 0.4 * pulse)), cv2.LINE_AA)

        # sparks (streaking white dashes)
        sp_on = sstep(2.3, 3.4, t) * 0.9 + 0.1 * sstep(9, 11, t)
        n_sp = int(220 * clamp(sp_on * (0.62 + 0.38 * sstep(3, 11, t))))
        sp_speed = 1.3 + 0.55 * travel_speed(t)
        for i in range(n_sp):
            z = ZMIN + ((self.sp_z0[i] - P * self.sp_v[i] * 1.55) % 34.0)
            dz = 0.07 * sp_speed * self.sp_v[i] + 0.24
            p1 = self.proj(self.sp_x[i], self.sp_y[i], z, psi(z), cx, cy)
            p0 = self.proj(self.sp_x[i], self.sp_y[i], z + dz, psi(z + dz), cx, cy)
            a = (1 - sstep(7, 13, z)) * sstep(0.8, 1.6, z)
            if a < 0.05:
                continue
            col = bgr(mix3((255, 255, 255), pal["core"], 0.35), a)
            cv2.line(L2, (int(p0[0]), int(p0[1])), (int(p1[0]), int(p1[1])), col,
                     3 + int(6.0 / z ** 0.9), cv2.LINE_AA)

        L = cv2.add(L1, L2)

        # --- chapter I beam -------------------------------------------
        bm = self.beam(t, pal)

        # --- glow (multi-scale) ---------------------------------------
        s4 = cv2.resize(L, (W // 4, H // 4), interpolation=cv2.INTER_AREA)
        g1 = cv2.GaussianBlur(s4, (0, 0), 2.4)
        s16 = cv2.resize(s4, (W // 16, H // 16), interpolation=cv2.INTER_AREA)
        g2 = cv2.GaussianBlur(s16, (0, 0), 2.0)
        s64 = cv2.resize(s16, (W // 64, H // 64), interpolation=cv2.INTER_AREA)
        g3 = cv2.GaussianBlur(s64, (0, 0), 1.4)
        up = lambda im: cv2.resize(im, (W, H), interpolation=cv2.INTER_LINEAR)

        out = cv2.add(base, L)
        out = cv2.addWeighted(out, 1.0, up(g1), 1.05, 0)
        out = cv2.addWeighted(out, 1.0, up(g2), 0.75, 0)
        out = cv2.addWeighted(out, 1.0, up(g3), 0.45, 0)
        if bm is not None:
            out = cv2.add(out, bm)
            sb = cv2.resize(bm, (W // 8, H // 8), interpolation=cv2.INTER_AREA)
            out = cv2.add(out, up(cv2.GaussianBlur(sb, (0, 0), 3)))

        # --- core glow (builds into the white flash) -------------------
        pre = sstep(12.0, 14.6, t)
        blast = sstep(14.75, 15.3, t)
        core_amt = 0.015 * corridor + 0.55 * pre + 3.2 * blast + 0.08 * pulse
        if core_amt > 0.01:
            sig = 0.03 + 0.05 * pre + 0.34 * blast ** 1.3
            glow = np.exp(-self.rq2 / (sig * sig))[..., None] * core_amt
            tint = np.array(mix3(pal["glow"], (255, 255, 255), max(blast, 0.35 * pre))[::-1], np.float32) / 255.0
            gl = np.clip(glow * tint * 255.0, 0, 255).astype(np.uint8)
            out = cv2.add(out, up(gl))

        # --- vignette ------------------------------------------------
        out = cv2.multiply(out, self.vig, scale=1 / 255.0)

        # --- chapter labels ------------------------------------------
        for s, e, lab in self.labels:
            if s <= t <= e:
                a = sstep(s, s + 0.5, t) * (1 - sstep(e - 0.7, e, t))
                if a > 0.01:
                    add = cv2.merge([(lab * a).astype(np.uint8)] * 3)
                    out = cv2.add(out, add)

        # --- white flash, black, outro --------------------------------
        lvl = float(np.interp(t, [15.12, 15.38, 15.9, 16.05, 16.4, 16.95], [0.0, 1.0, 0.975, 0.91, 0.91, 0.0]))
        if lvl > 0:
            if t > 15.9:                                   # flat grey, nothing shows through
                out = np.full_like(out, int(round(lvl * 255)))
            else:
                out = cv2.addWeighted(out, 1 - lvl, np.full_like(out, 255), lvl, 0)
        if t > 16.4:
            fade_in = sstep(17.0, 17.9, t)
            txt = cv2.merge([(self.outro_txt * fade_in).astype(np.uint8)] * 3)
            rule = (self.outro_rule * fade_in).astype(np.uint8)
            if t > 16.95:
                out = np.zeros_like(out)
            out = cv2.add(out, rule)
            out = cv2.add(out, txt)

        # --- start / end fades ----------------------------------------
        if t < 0.4:
            out = (out.astype(np.float32) * (0.35 + 0.65 * sstep(0, 0.4, t))).astype(np.uint8)
        if t > DUR - 0.5:
            out = (out.astype(np.float32) * (1 - sstep(DUR - 0.5, DUR, t))).astype(np.uint8)
        return out


def travel_speed(t):
    return float(np.interp(t, [k[0] for k in _KEYS], [k[1] for k in _KEYS]))


# ----------------------------------------------------------------------------
# Audio (pure numpy synth) - ambient drone, bass hits, riser, flash, outro
# ----------------------------------------------------------------------------
def synth_audio(path, sr=44100):
    n = int((DUR + 0.1) * sr)
    t = np.arange(n) / sr
    rng = np.random.default_rng(3)

    def env(points):
        return np.interp(t, [p[0] for p in points], [p[1] for p in points])

    def band_noise(lo, hi):
        spec = np.fft.rfft(rng.standard_normal(n))
        f = np.fft.rfftfreq(n, 1 / sr)
        spec[(f < lo) | (f > hi)] = 0
        x = np.fft.irfft(spec, n)
        return x / (np.abs(x).max() + 1e-9)

    L = np.zeros(n)
    R = np.zeros(n)

    # 1) D-minor pad (D2 D3 F3 A3 D4) with slow vibrato and detune
    pad_env = env([(0, 0.10), (1.5, 0.15), (3, 0.30), (7, 0.34), (11, 0.42), (16.3, 0.44),
                   (16.9, 0.03), (17.9, 0.03), (18.6, 0.30), (20.4, 0.28), (21.3, 0.0)])
    for f0, amp in ((73.42, 1.0), (146.83, 0.55), (174.61, 0.45), (220.0, 0.30), (293.66, 0.18)):
        for det, side in ((-0.6, 0), (0.6, 1)):
            vib = 1 + 0.002 * np.sin(2 * np.pi * (0.2 + 0.07 * f0 / 100) * t + f0)
            ph = 2 * np.pi * np.cumsum(f0 * (1 + det * 0.004) * vib) / sr
            tone = (np.sin(ph) + 0.35 * np.sin(2 * ph) + 0.15 * np.sin(3 * ph)) * amp * pad_env * 0.35
            (L if side == 0 else R)[:] += tone

    # 2) high shimmer (air) that grows with speed
    air = band_noise(3500, 12000) * env([(0, 0.010), (3, 0.028), (10, 0.045), (16.2, 0.06), (16.9, 0.0),
                                         (18, 0.012), (21, 0.006)])
    L += air
    R += np.roll(air, 211)

    # 3) bell sparkles (random high sines with fast decay)
    spark_t = np.sort(np.concatenate([rng.uniform(1.0, 3.0, 5), rng.uniform(3.0, 11.0, 34),
                                      rng.uniform(11.0, 16.0, 40)]))
    for st_ in spark_t:
        f = rng.choice([880, 1174.7, 1318.5, 1568, 1760, 2093])
        i0 = int(st_ * sr)
        m = min(n - i0, int(1.4 * sr))
        tt = np.arange(m) / sr
        s = np.sin(2 * np.pi * f * tt) * np.exp(-tt * 4.5) * rng.uniform(0.035, 0.08)
        pan = rng.uniform(0.2, 0.8)
        L[i0:i0 + m] += s * (1 - pan)
        R[i0:i0 + m] += s * pan

    # 4) bass hits at the chapter beats
    for b in BEATS:
        i0 = int(b * sr)
        m = min(n - i0, int(2.2 * sr))
        tt = np.arange(m) / sr
        freq = 32 + 70 * np.exp(-tt * 7)
        boom = np.sin(2 * np.pi * np.cumsum(freq) / sr) * np.exp(-tt * 2.6) * 0.62
        hiss = band_noise(60, 900)[:m] * np.exp(-tt * 6) * 0.18
        L[i0:i0 + m] += boom + hiss
        R[i0:i0 + m] += boom + hiss

    # 5) riser 11 -> 16.3
    r_env = env([(10.8, 0), (13.5, 0.07), (16.2, 0.30), (16.45, 0.0)])
    freq = 180 * (1600 / 180) ** np.clip((t - 10.8) / 5.5, 0, 1)
    ris = np.sin(2 * np.pi * np.cumsum(freq) / sr) * r_env * (0.6 + 0.4 * np.sin(2 * np.pi * (4 + (t - 11) * 2) * t))
    whoosh = band_noise(300, 7000) * r_env * 0.55
    L += ris + whoosh
    R += ris + np.roll(whoosh, 97)

    # 6) flash impact
    i0 = int(15.9 * sr)
    m = min(n - i0, int(2.0 * sr))
    tt = np.arange(m) / sr
    imp = np.sin(2 * np.pi * np.cumsum(28 + 55 * np.exp(-tt * 5)) / sr) * np.exp(-tt * 2.0) * 0.85
    sh = band_noise(80, 5000)[:m] * np.exp(-tt * 3.2) * 0.35
    L[i0:i0 + m] += imp + sh
    R[i0:i0 + m] += imp + sh

    # 7) outro low drone (D2 + sub + F3)
    o_env = env([(17.0, 0), (18.3, 0.16), (20.4, 0.15), (21.3, 0)])
    sub = np.sin(2 * np.pi * 55.0 * t) * o_env * 0.9 + np.sin(2 * np.pi * 87.3 * t) * o_env * 0.5
    L += sub
    R += sub

    # master: duck right after the flash, soft clip, fades
    duck = 1 - 0.85 * env([(16.4, 0), (16.8, 1), (17.4, 1), (18.3, 0)])
    duck[t < 16.4] = 1
    L *= duck
    R *= duck
    fade = np.clip(np.minimum(t / 0.3, (DUR - t) / 0.8), 0, 1)
    L = np.tanh(L * 1.1) * fade
    R = np.tanh(R * 1.1) * fade
    pk = max(np.abs(L).max(), np.abs(R).max(), 1e-6)
    stereo = np.stack([L, R], 1) / pk * 0.89
    data = (stereo * 32767).astype("<i2")
    with wave.open(path, "wb") as w:
        w.setnchannels(2)
        w.setsampwidth(2)
        w.setframerate(sr)
        w.writeframes(data.tobytes())


# ----------------------------------------------------------------------------
# Recording
# ----------------------------------------------------------------------------
def find_ffmpeg():
    p = shutil.which("ffmpeg")
    if p:
        return p
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="infinite_mirror.mp4")
    ap.add_argument("--fps", type=int, default=30)
    ap.add_argument("--stills", action="store_true", help="save a few PNG frames and exit")
    args = ap.parse_args()

    m = Mirror()

    if args.stills:
        os.makedirs("stills", exist_ok=True)
        for tt in (0.3, 1.3, 3.0, 5.5, 7.0, 9.6, 10.0, 12.0, 14.0, 15.2, 16.0, 17.8):
            cv2.imwrite(f"stills/t_{tt:05.2f}.png", m.frame(tt))
        print("saved stills/")
        return

    wav_path = "_audio.wav"
    print("Synthesising audio ...")
    synth_audio(wav_path)

    ff = find_ffmpeg()
    total = int(round(DUR * args.fps))
    if ff:
        cmd = [ff, "-y", "-loglevel", "error",
               "-f", "rawvideo", "-pix_fmt", "bgr24", "-s", f"{W}x{H}", "-r", str(args.fps), "-i", "-",
               "-i", wav_path,
               "-c:v", "libx264", "-preset", "medium", "-crf", "17", "-pix_fmt", "yuv420p",
               "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", "-shortest", args.out]
        proc = subprocess.Popen(cmd, stdin=subprocess.PIPE)
        sink = proc.stdin.write
    else:
        print("ffmpeg not found -> saving silent video + separate WAV (pip install imageio-ffmpeg to fix)")
        vw = cv2.VideoWriter(args.out, cv2.VideoWriter_fourcc(*"mp4v"), args.fps, (W, H))
        sink = lambda b: vw.write(np.frombuffer(b, np.uint8).reshape(H, W, 3))
        proc = None

    for i in range(total):
        t = i / args.fps
        sink(m.frame(t).tobytes())
        if i % 15 == 0:
            print(f"Rendering {i / total * 100:5.1f}%", end="\r", flush=True)

    if proc:
        proc.stdin.close()
        proc.wait()
        os.remove(wav_path)
    else:
        vw.release()
    print(f"\nDone -> {args.out}")


if __name__ == "__main__":
    main()
