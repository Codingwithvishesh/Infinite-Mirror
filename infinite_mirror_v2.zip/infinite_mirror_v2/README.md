# The Infinite Mirror v2

Renders a 21-second 1080x1920 (Reels) video with synthesized sound.

## Install
    pip install numpy opencv-python pillow imageio-ffmpeg

## Run
    python infinite_mirror.py
    python infinite_mirror.py --out my_reel.mp4
    python infinite_mirror.py --fps 60
    python infinite_mirror.py --stills     # saves a few PNG frames for a quick look

Keep the `fonts` folder next to the script (Poppins, used for the text).
Takes about 1.5-3 minutes to render.
